﻿XUXU 0.3.16 — Aaron's DAW (2026-10-19)
(Español abajo)

HOW TO OPEN IT
1. Unzip it (right-click → "Extract All") into a folder of yours, for example Documents\XUXU.
   Don't run it from inside the zip and don't put it in Program Files.
2. Double-click XUXU.exe.
3. If Windows says "Windows protected your PC": "More info" → "Run anyway".
   It shows up because XUXU doesn't have a Microsoft digital signature yet.

IT UPDATES ITSELF
- Every time you open it, it checks for a new version. If there is one, it shows what changed and asks:
  "Update" downloads it and restarts XUXU (if you have unsaved changes, it asks you to save first);
  "Later" lets you keep working and asks again next time.
- Don't want to wait? Options → Check for Updates… checks right away and installs it if there is one.
- You never have to download anything by hand again.
- If you had an older XUXU, delete the old folder and use this one.

WHAT YOU NEED
- Windows 10 or 11, 64-bit.
- Microsoft Edge WebView2 Runtime. Windows 11 already has it, and Windows 10 almost always does.
  If XUXU opens blank, install it from: https://developer.microsoft.com/microsoft-edge/webview2/
- It sounds best with an ASIO audio interface; without one it uses Windows audio.
  If Ableton or another DAW has the interface open, close it: ASIO only allows one program at a time.

THE FIRST TIME
- XUXU scans your VST3 plug-ins. If you have a lot of them, it takes a few minutes.
- Plug-ins in another folder? Options → Plug-in Folders… → Add Folder…
- Your projects are saved in Documents\XUXU.

MELODYNE (ARA)
- If you have Melodyne, put it on an audio track like any effect: it reads your takes directly.

IF XUXU CLOSES BY ITSELF
- Send Aaron the file Documents\XUXU\xuxu.log: it records where it crashed.

This is a work in progress: it can crash. If something breaks, let Aaron know.

------------------------------------------------------------------------------

ESPAÑOL

CÓMO ABRIRLO
1. Descomprime el zip (clic derecho → «Extraer todo») en una carpeta tuya, por ejemplo Documentos\XUXU.
   No lo abras desde dentro del zip ni lo pongas en Archivos de programa.
2. Doble clic en XUXU.exe.
3. Si Windows dice «Windows protegió tu PC»: «Más información» → «Ejecutar de todos modos».
   Sale porque XUXU todavía no tiene firma digital de Microsoft.

SE ACTUALIZA SOLO
- Cada vez que lo abres revisa si hay versión nueva. Si hay, te enseña lo que cambió y te pregunta:
  «Actualizar» la baja y reinicia XUXU (si tienes cambios sin guardar, primero te pregunta si guardas);
  «Después» te deja seguir y te vuelve a preguntar la próxima vez.
- ¿No quieres esperar? Opciones → Buscar actualizaciones… revisa al momento y, si hay, la instala.
- No tienes que volver a bajar nada a mano.
- Si ya tenías una XUXU anterior, borra la carpeta vieja y usa ésta.

QUÉ NECESITAS
- Windows 10 u 11 de 64 bits.
- Microsoft Edge WebView2 Runtime. Windows 11 ya lo trae y en Windows 10 casi siempre está.
  Si XUXU abre en blanco, instálalo de: https://developer.microsoft.com/microsoft-edge/webview2/
- Con una interfaz de audio con ASIO suena mejor; sin interfaz usa el audio de Windows.
  Si tienes Ableton u otro DAW abierto con la interfaz, ciérralo: ASIO sólo deja un programa a la vez.

LA PRIMERA VEZ
- XUXU revisa tus plugins VST3. Si tienes muchos, tarda unos minutos.
- ¿Plugins en otra carpeta? Opciones → Carpetas de plug-ins… → Agregar carpeta…
- Tus proyectos se guardan en Documentos\XUXU.

MELODYNE (ARA)
- Si tienes Melodyne, ponlo en una pista de audio como cualquier efecto: lee tus tomas directo.

SI XUXU SE CIERRA SOLO
- Mándale a Aaron el archivo Documentos\XUXU\xuxu.log: ahí queda escrito dónde tronó.

Es una versión en construcción: puede tronar. Si algo falla, avísale a Aaron.
